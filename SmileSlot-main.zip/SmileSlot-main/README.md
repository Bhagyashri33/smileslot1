![Smile Slot Logo(1)](https://user-images.githubusercontent.com/114407593/237023642-6049b701-bd06-415a-a72d-f9e745da54a0.png)

![smileslot_flowchart](https://user-images.githubusercontent.com/114407593/237023316-5c3108eb-dbb9-40a7-83cd-111cefae1651.png)

                                             Work-Flow of our system

![Index Page](https://user-images.githubusercontent.com/114407593/237024643-b5ee418e-c884-4058-a035-05765b664a9a.png)

                                                 Home Page

![Sign In Page](https://user-images.githubusercontent.com/114407593/237025430-850d260c-c515-4257-ad54-7d22ba6c5ce8.png)

                    Sign In Page [https://dull-cyan-hatchling-yoke.cyclic.app/users/login]
                                                         
![Sign Up Page](https://user-images.githubusercontent.com/114407593/237026165-7deecadc-da19-458d-889a-646c175c3463.png)

                    Sign Up Page [https://dull-cyan-hatchling-yoke.cyclic.app/users/signup]
                    
![Book Appointment Page](https://user-images.githubusercontent.com/114407593/237038119-382e1e90-f83c-4cd5-a92a-6c707783610f.png)

                  Book Appointment [https://dull-cyan-hatchling-yoke.cyclic.app/users/bookslot/:clinicId]

![Dentist Panel](https://user-images.githubusercontent.com/114407593/237027037-5db721ec-2b41-4e20-97cb-08befdaa65b9.png)
                                                         
                    Dentist Panel [https://dull-cyan-hatchling-yoke.cyclic.app/users/addclinic]

![Dentist Appointments](https://user-images.githubusercontent.com/114407593/237027635-ec99bfe6-c6d8-4d76-afe6-1efbed88496a.png)

            Dentist Appointments [https://dull-cyan-hatchling-yoke.cyclic.app/users/dentist/appointments]

![Users Data Admin Portal](https://github.com/anonymous10062002/mountainous-behavior-4917/assets/114407593/9204f4bc-98c6-490d-946d-79983ddf0a5a)

          Admin Portal to view & block users [https://dull-cyan-hatchling-yoke.cyclic.app/admin/getusers]
                  
![Clinic Data Admin Portal](https://github.com/anonymous10062002/mountainous-behavior-4917/assets/114407593/cf64f605-2177-44e9-9e42-2649f92a080b)

        Admin Portal to view & delete clinics [https://dull-cyan-hatchling-yoke.cyclic.app/admin/allclinics]

